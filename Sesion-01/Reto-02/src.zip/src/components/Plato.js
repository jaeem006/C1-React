import React from 'react';

const Plato = () => {
	return (
		<div className="plato" />
	);
};

export default Plato;