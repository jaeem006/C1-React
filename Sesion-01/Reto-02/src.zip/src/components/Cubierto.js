import React from 'react';

const Cubierto = () => {
	return (
		<div className="cubierto" />
	);
};

export default Cubierto;