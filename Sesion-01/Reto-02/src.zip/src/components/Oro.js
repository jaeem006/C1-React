import React from 'react';

const Oro = () => {
	return (
		<div className="oro" />
	);
};

export default Oro;
