import React from 'react';
import Mantel from './Mantel';

const TresManteles = () => {
	return (
		<div className="width100 spaceAround">
			<Mantel />
			<Mantel />
			<Mantel />
		</div>
	);
};

export default TresManteles;
