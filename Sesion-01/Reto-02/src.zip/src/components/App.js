import React from 'react';
import Mesa from './Mesa';

const App = () => {
   return (
      <Mesa />
   );
};

export default App;